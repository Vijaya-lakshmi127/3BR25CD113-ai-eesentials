"""
Resume Analyzer Engine
Handles text extraction from PDF, DOCX, TXT, contact detail extraction,
section parsing, skills discovery, and ATS scoring calculation.
"""

import io
import re
from typing import List, Dict, Any, Optional, Tuple
import pypdf
import docx

# Extensive taxonomy of skills categorized by domain
SKILLS_TAXONOMY = {
    "Programming Languages": [
        "python", "javascript", "typescript", "java", "c++", "c#", "c", "golang", "go",
        "ruby", "php", "swift", "kotlin", "rust", "scala", "r", "dart", "shell", "bash", "powershell", "sql"
    ],
    "Web & Frontend Frameworks": [
        "react", "react.js", "next.js", "vue", "vue.js", "angular", "svelte", "html", "html5",
        "css", "css3", "sass", "scss", "tailwind", "tailwind css", "bootstrap", "material ui",
        "redux", "zustand", "webpack", "vite", "graphql", "rest api"
    ],
    "Backend & Server Frameworks": [
        "node.js", "express", "express.js", "django", "fastapi", "flask", "spring boot", "spring",
        ".net", "asp.net", "ruby on rails", "laravel", "nest.js", "microservices", "grpc", "graphql"
    ],
    "Databases & Caching": [
        "postgresql", "postgres", "mysql", "mongodb", "sqlite", "redis", "elasticsearch",
        "dynamodb", "cassandra", "oracle", "mariadb", "firebase", "supabase", "neo4j"
    ],
    "Cloud & DevOps": [
        "aws", "amazon web services", "azure", "google cloud", "gcp", "docker", "kubernetes", "k8s",
        "terraform", "ansible", "jenkins", "ci/cd", "github actions", "gitlab ci", "helm",
        "prometheus", "grafana", "linux", "nginx", "apache"
    ],
    "Data Science, AI & Machine Learning": [
        "machine learning", "deep learning", "artificial intelligence", "nlp", "computer vision",
        "tensorflow", "pytorch", "scikit-learn", "pandas", "numpy", "opencv", "hugging face",
        "transformers", "llms", "large language models", "langchain", "llamaindex", "generative ai",
        "tableau", "power bi", "matplotlib", "seaborn", "data analysis", "data visualization", "etl", "spark", "hadoop"
    ],
    "Tools, Testing & Methods": [
        "git", "github", "gitlab", "bitbucket", "jira", "confluence", "trello", "postman",
        "selenium", "cypress", "playwright", "pytest", "junit", "jest", "agile", "scrum", "kanban", "figma", "wireframing"
    ],
    "Soft Skills & Leadership": [
        "leadership", "team management", "stakeholder communication", "mentorship", "cross-functional collaboration",
        "problem solving", "analytical thinking", "critical thinking", "project management", "time management",
        "presentation skills", "negotiation", "conflict resolution", "client management"
    ]
}

# Standard resume section headers
SECTION_PATTERNS = {
    "Summary / Objective": r"(professional\s+summary|executive\s+summary|summary|profile|about\s+me|career\s+objective|objective)",
    "Work Experience": r"(work\s+experience|professional\s+experience|experience|employment\s+history|work\s+history|internships)",
    "Education": r"(education|academic\s+background|academic\s+history|qualifications)",
    "Skills": r"(technical\s+skills|core\s+competencies|skills|skills\s+&\s+tools|technologies|expertise)",
    "Projects": r"(projects|key\s+projects|academic\s+projects|personal\s+projects)",
    "Certifications": r"(certifications|certificates|licenses|courses|accreditations)",
    "Awards / Achievements": r"(honors|awards|achievements|recognitions|extracurricular)",
    "Publications / Patents": r"(publications|research|patents|papers)"
}


def extract_text_from_pdf(file_bytes: bytes) -> str:
    """Extracts raw text content from uploaded PDF bytes."""
    text_parts = []
    try:
        reader = pypdf.PdfReader(io.BytesIO(file_bytes))
        for page in reader.pages:
            page_text = page.extract_text()
            if page_text:
                text_parts.append(page_text)
    except Exception as e:
        return f"Error extracting PDF: {str(e)}"
    return "\n".join(text_parts)


def extract_text_from_docx(file_bytes: bytes) -> str:
    """Extracts raw text content from uploaded DOCX bytes, including tables."""
    text_parts = []
    try:
        doc = docx.Document(io.BytesIO(file_bytes))
        for para in doc.paragraphs:
            if para.text.strip():
                text_parts.append(para.text)
        for table in doc.tables:
            for row in table.rows:
                row_text = [cell.text.strip() for cell in row.cells if cell.text.strip()]
                if row_text:
                    text_parts.append(" | ".join(row_text))
    except Exception as e:
        return f"Error extracting DOCX: {str(e)}"
    return "\n".join(text_parts)


def extract_contact_info(text: str) -> Dict[str, Any]:
    """Extracts candidate contact details: email, phone, links, and name."""
    email_match = re.search(r"[\w\.-]+@[\w\.-]+\.\w+", text)
    email = email_match.group(0) if email_match else None
    
    # Phone number extraction
    phone_match = re.search(r"(\+?\d{1,3}[\s-]?)?(\(?\d{3}\)?[\s-]?)?\d{3}[\s-]?\d{4}", text)
    phone = phone_match.group(0).strip() if phone_match else None
    
    # Links
    linkedin_match = re.search(r"(linkedin\.com/in/[\w\-]+)", text, re.IGNORECASE)
    linkedin = f"https://www.{linkedin_match.group(0)}" if linkedin_match else None
    
    github_match = re.search(r"(github\.com/[\w\-]+)", text, re.IGNORECASE)
    github = f"https://www.{github_match.group(0)}" if github_match else None
    
    portfolio_match = re.search(r"https?://(?:www\.)?([a-zA-Z0-9-]+\.(?:dev|me|io|com|app|portfolio|tech)(?:/[\w\-]*)*)", text, re.IGNORECASE)
    portfolio = portfolio_match.group(0) if portfolio_match else None
    
    # Guess candidate name (usually in the first 3 non-empty lines)
    lines = [line.strip() for line in text.split("\n") if line.strip()]
    candidate_name = "Candidate"
    for line in lines[:4]:
        # Exclude common headers
        if re.search(r"(resume|curriculum|vitae|contact|phone|email|summary)", line, re.I):
            continue
        # Names are typically 2 to 4 words, letters only
        words = line.split()
        if 1 <= len(words) <= 4 and all(w.replace(".", "").isalpha() for w in words):
            candidate_name = line
            break

    return {
        "name": candidate_name,
        "email": email,
        "phone": phone,
        "linkedin": linkedin,
        "github": github,
        "portfolio": portfolio
    }


def detect_sections(text: str) -> Dict[str, bool]:
    """Detects presence of essential resume sections."""
    detected = {}
    lower_text = text.lower()
    for section_name, pattern in SECTION_PATTERNS.items():
        match = re.search(r"(?:^|\n)\s*" + pattern + r"\b", lower_text)
        detected[section_name] = bool(match)
    return detected


def extract_skills(text: str) -> Dict[str, Any]:
    """Scans and extracts recognized skills grouped by domain."""
    lower_text = text.lower()
    found_by_category = {}
    all_found_skills = set()
    
    for category, skill_list in SKILLS_TAXONOMY.items():
        matched = []
        for skill in skill_list:
            # Word boundary regex for exact matching
            pattern = r"(?<![\w\.-])" + re.escape(skill) + r"(?![\w\.-])"
            if re.search(pattern, lower_text):
                matched.append(skill)
                all_found_skills.add(skill)
        if matched:
            found_by_category[category] = matched
            
    return {
        "categorized_skills": found_by_category,
        "all_skills": sorted(list(all_found_skills)),
        "total_skills_count": len(all_found_skills)
    }


def calculate_ats_score(
    text: str,
    contact_info: Dict[str, Any],
    detected_sections: Dict[str, bool],
    skills_data: Dict[str, Any],
    style_data: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Computes standard industry ATS Score (0 - 100) with detailed component breakdown.
    """
    words = text.split()
    word_count = len(words)
    
    # 1. Section Header Completeness (Max: 20 points)
    critical_sections = ["Work Experience", "Education", "Skills", "Summary / Objective", "Projects"]
    present_critical = sum(1 for s in critical_sections if detected_sections.get(s, False))
    section_score = round((present_critical / len(critical_sections)) * 20, 1)
    
    # 2. Contact Information Completeness (Max: 15 points)
    contact_score = 0
    if contact_info.get("email"):
        contact_score += 5
    if contact_info.get("phone"):
        contact_score += 4
    if contact_info.get("linkedin"):
        contact_score += 3
    if contact_info.get("github") or contact_info.get("portfolio"):
        contact_score += 3
        
    # 3. Action Verbs & Measurable Metrics (Max: 25 points)
    stats = style_data.get("metrics_stats", {})
    metric_pct = stats.get("metric_percentage", 0)
    action_pct = stats.get("action_verb_percentage", 0)
    
    # Metric scoring (up to 15 pts)
    if metric_pct >= 40:
        metric_score = 15
    elif metric_pct >= 20:
        metric_score = 11
    elif metric_pct > 0:
        metric_score = 7
    else:
        metric_score = 2
        
    # Action verb scoring (up to 10 pts)
    if action_pct >= 60:
        action_score = 10
    elif action_pct >= 30:
        action_score = 7
    else:
        action_score = 4
    
    verbs_metrics_score = metric_score + action_score
    
    # 4. Technical & Domain Skills Depth (Max: 20 points)
    total_skills = skills_data.get("total_skills_count", 0)
    if total_skills >= 18:
        skill_score = 20
    elif total_skills >= 12:
        skill_score = 16
    elif total_skills >= 7:
        skill_score = 12
    elif total_skills >= 3:
        skill_score = 8
    else:
        skill_score = 3
        
    # 5. Formatting, Length & Grammar (Max: 20 points)
    format_score = 20
    # Length check: Ideal resume length is 350 - 950 words (1-2 pages)
    if word_count < 250:
        format_score -= 8  # Too sparse
    elif word_count > 1200:
        format_score -= 5  # Too verbose for 1-2 pages
        
    # Style penalty
    style_score = style_data.get("style_score", 100)
    if style_score < 70:
        format_score -= 5
    elif style_score < 85:
        format_score -= 2
        
    format_score = max(5, format_score)
    
    # Calculate Total ATS Score
    total_ats = round(section_score + contact_score + verbs_metrics_score + skill_score + format_score)
    total_ats = max(10, min(100, total_ats))
    
    # Grade and ATS Status
    if total_ats >= 85:
        grade = "A+"
        status = "Strong ATS Pass"
        status_color = "#10B981"  # Emerald green
        status_desc = "Your resume has high ATS compatibility and is well-optimized for recruitment crawlers."
    elif total_ats >= 70:
        grade = "B"
        status = "Competitive (Needs Minor Polish)"
        status_color = "#3B82F6"  # Blue
        status_desc = "Your resume passes most filters, but adding quantified impact and filling keyword gaps will push it to top-tier."
    elif total_ats >= 50:
        grade = "C"
        status = "Needs Improvement"
        status_color = "#F59E0B"  # Amber
        status_desc = "Your resume is at risk of being screened out. Improve missing sections, action verbs, and quantifiable metrics."
    else:
        grade = "D"
        status = "ATS Screening Risk"
        status_color = "#EF4444"  # Red
        status_desc = "Your resume lacks key technical keywords, contact elements, or standard structural sections."

    # Identify Key Strengths and Improvement Areas
    strengths = []
    improvements = []
    
    if present_critical >= 4:
        strengths.append("Structured with essential industry standard section headers.")
    else:
        missing_sec = [s for s in critical_sections if not detected_sections.get(s, False)]
        improvements.append(f"Add missing critical sections: {', '.join(missing_sec)}.")
        
    if contact_score >= 12:
        strengths.append("Complete contact profile with direct digital presence links.")
    else:
        improvements.append("Include complete contact details (LinkedIn, GitHub/Portfolio, Phone).")
        
    if metric_pct >= 25:
        strengths.append(f"Strong quantified achievements: {metric_pct}% of bullet points contain metrics.")
    else:
        improvements.append("Quantify your accomplishments! Use numbers, percentages (%), dollar amounts, or scale to prove impact.")
        
    if total_skills >= 10:
        strengths.append(f"Broad skill portfolio ({total_skills} recognized tools and frameworks detected).")
    else:
        improvements.append("Expand your technical skills section with specific tools, frameworks, and methodologies.")
        
    if len(style_data.get("weak_words", [])) == 0:
        strengths.append("Clean, active phrasing with minimal passive voice.")
    else:
        improvements.append(f"Replace {len(style_data.get('weak_words', []))} passive/weak words with high-impact power verbs.")

    return {
        "overall_score": total_ats,
        "grade": grade,
        "status": status,
        "status_color": status_color,
        "status_desc": status_desc,
        "breakdown": {
            "Sections Completeness": {"score": section_score, "max": 20},
            "Contact Details": {"score": contact_score, "max": 15},
            "Action Verbs & Metrics": {"score": verbs_metrics_score, "max": 25},
            "Skills Density": {"score": skill_score, "max": 20},
            "Formatting & Length": {"score": format_score, "max": 20},
        },
        "word_count": word_count,
        "strengths": strengths,
        "improvements": improvements
    }


def match_job_description(resume_text: str, jd_text: str, extracted_skills: List[str]) -> Dict[str, Any]:
    """
    Compares candidate's resume directly against a target Job Description (JD),
    identifying keyword match percentage, shared skills, and missing essential keywords.
    """
    if not jd_text.strip():
        return {}
        
    # Extract skills present in JD
    jd_skills_data = extract_skills(jd_text)
    jd_skills = set(jd_skills_data["all_skills"])
    resume_skills = set(s.lower() for s in extracted_skills)
    
    # Matched vs missing skills
    matched_skills = sorted(list(jd_skills.intersection(resume_skills)))
    missing_skills = sorted(list(jd_skills.difference(resume_skills)))
    
    # Calculate match percentage
    if jd_skills:
        match_rate = round((len(matched_skills) / len(jd_skills)) * 100, 1)
    else:
        # Fallback to word token overlap if no taxonomy skills found in JD
        jd_words = set(re.findall(r"\b[a-zA-Z]{3,}\b", jd_text.lower()))
        resume_words = set(re.findall(r"\b[a-zA-Z]{3,}\b", resume_text.lower()))
        overlap = jd_words.intersection(resume_words)
        match_rate = round((len(overlap) / len(jd_words)) * 100, 1) if jd_words else 0
        
    return {
        "match_percentage": match_rate,
        "total_jd_keywords": len(jd_skills),
        "matched_skills": matched_skills,
        "missing_skills": missing_skills
    }
