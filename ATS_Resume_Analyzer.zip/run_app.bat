@echo off
title ATS Resume Analyzer
echo ========================================================
echo   Starting ATS Resume Analyzer & Career Optimizer
echo   Local URL: http://localhost:8501
echo ========================================================
py -m streamlit run app.py
pause
