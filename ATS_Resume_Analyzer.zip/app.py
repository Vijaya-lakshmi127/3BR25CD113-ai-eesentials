"""
AI & ATS Resume Analyzer, Career Role Recommender & Grammar Optimizer
Main Streamlit Application
"""

import streamlit as st
import json
from typing import Dict, Any

from analyzer_engine import (
    extract_text_from_pdf,
    extract_text_from_docx,
    extract_contact_info,
    detect_sections,
    extract_skills,
    calculate_ats_score,
    match_job_description,
    SKILLS_TAXONOMY
)
from role_recommender import (
    recommend_job_roles,
    determine_experience_level,
    ROLE_TAXONOMY
)
from grammar_style_checker import (
    analyze_grammar_and_wording,
    generate_sentence_improvement_preview,
    POWER_VERBS_BY_DOMAIN
)


# Page configuration and custom styles are initialized in main()

# Sample resumes for instant demonstration
SAMPLE_TECH_RESUME = """
Alex Johnson
alex.johnson@email.com | +1 (555) 234-5678 | linkedin.com/in/alex-johnson-dev | github.com/alexjohnson
San Francisco, CA

PROFESSIONAL SUMMARY
Dynamic and results-driven Software Engineer with 4+ years of hands-on experience building scalable web applications and microservices. Proven expertise in Python, JavaScript, React, and cloud architectures. Passionate team player who thrives in fast-paced agile environments.

WORK EXPERIENCE
Full Stack Engineer | CloudTech Solutions | June 2022 - Present
• Responsible for building client-facing web portals using React, TypeScript, and Node.js.
• Worked on microservices architecture with Python FastAPI and PostgreSQL, serving 150,000+ daily active users.
• Helped to migrate legacy monolith infrastructure to AWS Docker and Kubernetes, reducing cloud spend by 22%.
• Lead a team of 4 junior developers and participated in daily scrum standups and sprint planning.
• Fixed critical database query bottlenecks in PostgreSQL and implemented Redis caching, boosting API response latency by 45%.

Software Developer | NextGen Apps | August 2020 - May 2022
• Handled development of responsive frontend interfaces using React, Redux, and Tailwind CSS.
• Developed REST APIs with Django and PostgreSQL to process online payment transactions exceeding $2M monthly.
• Assisted in writing automated unit tests using PyTest and Jest, achieving 88% code test coverage.
• Duties included troubleshooting production incidents and monitoring application health using Datadog and Git.

EDUCATION
Bachelor of Science in Computer Science | University of California, Berkeley | 2016 - 2020
• GPA: 3.8 / 4.0 | Dean's Honor List

TECHNICAL SKILLS
• Programming Languages: Python, JavaScript, TypeScript, SQL, Bash
• Web & Frameworks: React, Node.js, Express, FastAPI, Django, HTML5, CSS3, Tailwind CSS
• Databases & Caching: PostgreSQL, Redis, MongoDB
• Cloud & DevOps: AWS, Docker, Kubernetes, Git, CI/CD, GitHub Actions
• Tools & Methodologies: Jira, Postman, Agile, Scrum, REST API

PROJECTS
• Real-time Collaboration Whiteboard: Developed interactive multi-user whiteboard using WebSockets, React, and Node.js with 1,000+ registered users.
• Automated Document Parser: Engineered OCR pipeline in Python and Docker to parse invoices with 98% accuracy.
"""

SAMPLE_DATA_RESUME = """
Elena Rostova
elena.rostova@analytics.org | +1 (555) 876-5432 | linkedin.com/in/elena-rostova | github.com/erostova
New York, NY

PROFESSIONAL SUMMARY
Detail-oriented Data Analyst with 3 years of experience in data visualization, SQL query optimization, and statistical modeling. Dedicated hard worker skilled in translating complex business datasets into clear executive dashboards.

WORK EXPERIENCE
Data Analyst | Global Retail Corporation | Jan 2023 - Present
• Responsible for creating weekly executive sales dashboards in Tableau and Power BI across 50 retail branches.
• Handled data extraction and transformation pipelines using SQL, Python, and Pandas from Snowflake data warehouse.
• Worked on customer churn prediction models using Scikit-Learn and Logistic Regression, identifying at-risk accounts with 84% precision.
• Did monthly ad-hoc business reporting for VP of Finance, uncovering $350k in inventory supply leakages.

Junior Data Analyst | Metro Insights | July 2021 - Dec 2022
• Assisted with data cleaning and validation using Excel and SQL for marketing campaign performance.
• Built interactive charts and reports tracking customer acquisition costs and lifetime value (LTV).
• Talked with business stakeholders to gather dashboard requirements and define key performance indicators (KPIs).

EDUCATION
B.S. in Statistics & Applied Economics | New York University | 2017 - 2021

SKILLS
• Languages & Querying: Python, SQL, R
• Analysis & ML: Pandas, NumPy, Scikit-learn, Statistics, Data Analysis, ETL
• BI & Visualization: Tableau, Power BI, Excel, Data Visualization
• Tools: Snowflake, Git, Jupyter
"""


def main():
    # Page configuration
    st.set_page_config(
        page_title="ATS Resume Analyzer & Career Optimizer",
        page_icon="📄",
        layout="wide",
        initial_sidebar_state="expanded"
    )

    # Custom CSS styling for modern executive UI
    st.markdown("""
    <style>
        /* Main header styling */
        .main-title {
            font-size: 2.3rem;
            font-weight: 800;
            background: linear-gradient(90deg, #1E3A8A, #3B82F6, #10B981);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 0.2rem;
        }
        .sub-title {
            font-size: 1.05rem;
            color: #4B5563;
            margin-bottom: 1.5rem;
        }
        /* Card containers */
        .metric-card {
            background-color: #FFFFFF;
            border: 1px solid #E5E7EB;
            border-radius: 12px;
            padding: 18px 22px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
            margin-bottom: 15px;
        }
        .score-badge {
            font-size: 2.8rem;
            font-weight: 900;
            text-align: center;
            line-height: 1;
            margin: 10px 0;
        }
        /* Pill tags */
        .skill-pill {
            display: inline-block;
            background-color: #EEF2FF;
            color: #4338CA;
            font-weight: 600;
            font-size: 0.82rem;
            padding: 4px 10px;
            border-radius: 20px;
            margin: 3px 4px;
            border: 1px solid #C7D2FE;
        }
        .missing-pill {
            display: inline-block;
            background-color: #FEF2F2;
            color: #B91C1C;
            font-weight: 600;
            font-size: 0.82rem;
            padding: 4px 10px;
            border-radius: 20px;
            margin: 3px 4px;
            border: 1px solid #FECACA;
        }
        .pill-green {
            display: inline-block;
            background-color: #ECFDF5;
            color: #047857;
            font-weight: 600;
            font-size: 0.82rem;
            padding: 4px 10px;
            border-radius: 20px;
            margin: 3px 4px;
            border: 1px solid #A7F3D0;
        }
    </style>
    """, unsafe_allow_html=True)

    # Sidebar
    st.sidebar.image("https://img.icons8.com/color/96/000000/curriculum-vitae.png", width=70)
    st.sidebar.title("Resume Workspace")
    
    upload_mode = st.sidebar.radio(
        "Input Method:",
        ["Upload File (PDF / DOCX / TXT)", "Paste Resume Text", "Load Sample Resume"],
        index=0
    )
    
    resume_text = ""
    
    if upload_mode == "Upload File (PDF / DOCX / TXT)":
        uploaded_file = st.sidebar.file_uploader(
            "Upload Resume",
            type=["pdf", "docx", "txt"],
            help="Supported formats: PDF, DOCX, TXT (Max 10MB)"
        )
        if uploaded_file is not None:
            file_bytes = uploaded_file.read()
            if uploaded_file.name.endswith(".pdf"):
                with st.spinner("Extracting PDF text..."):
                    resume_text = extract_text_from_pdf(file_bytes)
            elif uploaded_file.name.endswith(".docx"):
                with st.spinner("Extracting DOCX text..."):
                    resume_text = extract_text_from_docx(file_bytes)
            elif uploaded_file.name.endswith(".txt"):
                resume_text = file_bytes.decode("utf-8", errors="ignore")
                
            st.sidebar.success(f"Loaded: {uploaded_file.name}")
            
    elif upload_mode == "Paste Resume Text":
        resume_text = st.sidebar.text_area(
            "Paste Resume Text:",
            height=300,
            placeholder="Paste complete resume contents here..."
        )
    else:  # Load Sample Resume
        sample_choice = st.sidebar.selectbox(
            "Choose Sample Resume:",
            ["Full-Stack Software Engineer (Alex Johnson)", "Data Analyst (Elena Rostova)"]
        )
        if "Full-Stack" in sample_choice:
            resume_text = SAMPLE_TECH_RESUME
        else:
            resume_text = SAMPLE_DATA_RESUME
        st.sidebar.info("Sample resume loaded. You can inspect all tabs!")

    # Optional Target Job Description in Sidebar
    st.sidebar.markdown("---")
    st.sidebar.subheader("🎯 Target Job Description")
    st.sidebar.caption("Optional: Compare your resume against a specific job posting to test ATS keyword match.")
    jd_input = st.sidebar.text_area(
        "Paste Job Description:",
        height=150,
        placeholder="Paste target job requirements / description here..."
    )

    # Main App Header
    st.markdown('<div class="main-title">ATS Resume Analyzer & Career Optimizer</div>', unsafe_allow_html=True)
    st.markdown('<div class="sub-title">Instant ATS Scoring • Job Role Recommendations • Grammar & Professional Action-Verb Enhancer</div>', unsafe_allow_html=True)

    if not resume_text.strip():
        # Empty state prompt
        st.info("👈 **Get Started**: Upload your resume in the sidebar, paste your resume text, or select **'Load Sample Resume'** to see an immediate interactive analysis.")
        
        # Feature Highlights Cards
        col1, col2, col3 = st.columns(3)
        with col1:
            st.markdown("""
            <div class="metric-card">
                <h3>📊 ATS Compatibility Score</h3>
                <p>Simulates modern Applicant Tracking Systems (Workday, Greenhouse, Lever, Taleo) evaluating section structure, contact links, metric density, and skill relevance.</p>
            </div>
            """, unsafe_allow_html=True)
        with col2:
            st.markdown("""
            <div class="metric-card">
                <h3>💼 Job Role Matcher</h3>
                <p>Matches your technical and domain skills against 12+ industry standard tech, data, and management roles, computing fit percentage and customized learning roadmaps.</p>
            </div>
            """, unsafe_allow_html=True)
        with col3:
            st.markdown("""
            <div class="metric-card">
                <h3>✍️ Professional Word Polish</h3>
                <p>Detects weak verbs ('responsible for', 'helped to'), corporate buzzwords, first-person pronouns, and grammatical confusions with 1-click active power verb replacements.</p>
            </div>
            """, unsafe_allow_html=True)
        return

    # Process Analysis
    with st.spinner("Analyzing resume content, ATS metrics, and career fit..."):
        contact_info = extract_contact_info(resume_text)
        detected_sections = detect_sections(resume_text)
        skills_data = extract_skills(resume_text)
        style_data = analyze_grammar_and_wording(resume_text)
        ats_result = calculate_ats_score(
            resume_text, contact_info, detected_sections, skills_data, style_data
        )
        role_recommendations = recommend_job_roles(skills_data["all_skills"], resume_text)
        experience_tier = determine_experience_level(resume_text)
        jd_match = match_job_description(resume_text, jd_input, skills_data["all_skills"]) if jd_input.strip() else None

    # TABS INTERFACE
    tab_overview, tab_roles, tab_grammar, tab_jd, tab_export = st.tabs([
        "📊 ATS Score & Overview",
        "🎯 Job Role Recommendations",
        "✍️ Professional Wording & Grammar",
        "🔍 Target Job Description Matcher",
        "📥 Export Report"
    ])

    # ---------------- TAB 1: ATS SCORE & OVERVIEW ----------------
    with tab_overview:
        col_score, col_details = st.columns([1, 2])
        
        with col_score:
            st.markdown(f"""
            <div class="metric-card" style="text-align: center;">
                <div style="font-size: 1.1rem; color: #6B7280; font-weight: 700;">OVERALL ATS SCORE</div>
                <div class="score-badge" style="color: {ats_result['status_color']};">
                    {ats_result['overall_score']}<span style="font-size: 1.5rem; color: #9CA3AF;"> / 100</span>
                </div>
                <div style="display: inline-block; padding: 4px 14px; border-radius: 20px; font-weight: 700; color: white; background-color: {ats_result['status_color']};">
                    Grade {ats_result['grade']} — {ats_result['status']}
                </div>
                <p style="margin-top: 15px; font-size: 0.9rem; color: #4B5563;">
                    {ats_result['status_desc']}
                </p>
            </div>
            """, unsafe_allow_html=True)
            
            # Quick Stats
            st.markdown(f"""
            <div class="metric-card">
                <b>Candidate Profile:</b> {contact_info['name']}<br>
                <b>Detected Experience:</b> {experience_tier['badge']}<br>
                <b>Total Word Count:</b> {ats_result['word_count']} words<br>
                <b>Skills Recognized:</b> {skills_data['total_skills_count']} skills<br>
                <b>Quantified Bullets:</b> {style_data['metrics_stats']['metric_percentage']}%
            </div>
            """, unsafe_allow_html=True)

        with col_details:
            st.markdown("### 📋 ATS Breakdown Criteria")
            for criterion, data in ats_result["breakdown"].items():
                score = data["score"]
                max_score = data["max"]
                pct = int((score / max_score) * 100)
                st.write(f"**{criterion}**: `{score} / {max_score}` pts")
                st.progress(pct)

        # Contact Elements Verified
        st.markdown("---")
        st.subheader("📇 Contact Profile Elements")
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Email Address", "Present" if contact_info["email"] else "Missing", contact_info["email"] or "None detected")
        c2.metric("Phone Number", "Present" if contact_info["phone"] else "Missing", contact_info["phone"] or "None detected")
        c3.metric("LinkedIn Profile", "Present" if contact_info["linkedin"] else "Missing", "Linked" if contact_info["linkedin"] else "Add LinkedIn")
        c4.metric("GitHub / Portfolio", "Present" if (contact_info["github"] or contact_info["portfolio"]) else "Missing", "Linked" if (contact_info["github"] or contact_info["portfolio"]) else "Add Link")

        # Strengths & Critical Improvements
        st.markdown("---")
        col_str, col_imp = st.columns(2)
        with col_str:
            st.success("### ✅ Key ATS Strengths")
            for s in ats_result["strengths"]:
                st.markdown(f"• **{s}**")
        with col_imp:
            st.warning("### ⚠️ Actionable ATS Fixes")
            for imp in ats_result["improvements"]:
                st.markdown(f"• {imp}")

        # Section Headers Checklist
        st.markdown("---")
        st.subheader("📑 Standard Section Headers Audit")
        sec_cols = st.columns(4)
        for idx, (sec_name, detected) in enumerate(detected_sections.items()):
            col = sec_cols[idx % 4]
            if detected:
                col.markdown(f"✅ **{sec_name}**")
            else:
                col.markdown(f"❌ <span style='color: #EF4444;'>{sec_name}</span>", unsafe_allow_html=True)

    # ---------------- TAB 2: JOB ROLE RECOMMENDATIONS ----------------
    with tab_roles:
        st.subheader("🎯 Tailored Job Role Matches")
        st.caption("Based on extracted technical competencies, frameworks, tools, and experience depth.")
        
        st.info(f"**Assessed Career Tier:** {experience_tier['badge']} (Inferred from role titles & accomplishments).")

        top_roles = role_recommendations[:5]
        for role in top_roles:
            pct = role["match_percentage"]
            color = role["badge_color"]
            
            with st.expander(f"{role['role']} — {pct}% Match ({role['readiness']})", expanded=(pct >= 60)):
                st.write(f"**Domain:** {role['domain']}")
                st.write(f"**Role Summary:** {role['description']}")
                st.progress(int(pct))
                
                col_m, col_g = st.columns(2)
                with col_m:
                    st.markdown("**Matched Skills You Have:**")
                    if role["matched_skills"]:
                        pills_html = " ".join([f"<span class='pill-green'>✓ {s}</span>" for s in role["matched_skills"]])
                        st.markdown(pills_html, unsafe_allow_html=True)
                    else:
                        st.write("None detected yet.")
                        
                with col_g:
                    st.markdown("**High-Priority Skill Gaps to Acquire:**")
                    if role["missing_core_skills"]:
                        gap_html = " ".join([f"<span class='missing-pill'>+ {s}</span>" for s in role["missing_core_skills"]])
                        st.markdown(gap_html, unsafe_allow_html=True)
                    else:
                        st.markdown("<span style='color: #059669; font-weight:600;'>All core skills present!</span>", unsafe_allow_html=True)
                
                st.markdown(f"💡 **Recommended Learning Roadmap:** {role['roadmap']}")

        # Complete Skills Inventory
        st.markdown("---")
        st.subheader("🛠️ Extracted Skills Catalog")
        if skills_data["categorized_skills"]:
            for cat, items in skills_data["categorized_skills"].items():
                st.markdown(f"**{cat}** ({len(items)})")
                pills = " ".join([f"<span class='skill-pill'>{item}</span>" for item in items])
                st.markdown(pills, unsafe_allow_html=True)
        else:
            st.warning("No standard technical skills were extracted. Please ensure skills are explicitly listed under a 'Skills' header.")

    # ---------------- TAB 3: PROFESSIONAL WORDING & GRAMMAR ----------------
    with tab_grammar:
        st.subheader("✍️ Executive Wording & Grammar Polish")
        st.caption("Transform passive duties into impactful, metrics-driven leadership bullet points.")

        c_g1, c_g2, c_g3 = st.columns(3)
        c_g1.metric("Wording & Tone Score", f"{style_data['style_score']} / 100")
        c_g2.metric("Bullet Metric Density", f"{style_data['metrics_stats']['metric_percentage']}%", "Target: ≥ 30%")
        c_g3.metric("Action Verb Rate", f"{style_data['metrics_stats']['action_verb_percentage']}%", "Target: ≥ 60%")

        # Interactive Rewriter Tool
        st.markdown("---")
        st.markdown("### ⚡ Interactive Bullet Point Polisher")
        st.caption("Test how weak phrases or first-person statements are upgraded to executive action bullets.")
        
        sample_weak = "I was responsible for developing the backend and helped the team fix database bugs."
        user_sentence = st.text_input("Enter a resume sentence to polish:", value=sample_weak)
        if st.button("✨ Polish Bullet Point", type="primary"):
            preview = generate_sentence_improvement_preview(user_sentence)
            st.markdown(f"""
            <div class="metric-card" style="border-left: 5px solid #10B981;">
                <b>Original:</b> <i>"{preview['original']}"</i><br><br>
                <b>Polished Action Bullet:</b> <span style="font-size: 1.05rem; font-weight: 700; color: #047857;">"{preview['polished']}"</span><br><br>
                <b>Enhancements Made:</b> {', '.join(preview['changes']) if preview['changes'] else 'Maintained active tone'}<br>
                <b>Metric Tip:</b> {preview['quantifier_tip']}
            </div>
            """, unsafe_allow_html=True)

        # Weak Words Detected
        st.markdown("---")
        st.markdown(f"### 🔍 Passive & Weak Verbs Detected ({len(style_data['weak_words'])})")
        if style_data["weak_words"]:
            st.write("Replace these passive phrases with strong, quantifiable power verbs:")
            for item in style_data["weak_words"]:
                with st.expander(f"Line {item['line_number']}: '{item['detected_term']}' — {item['category']}"):
                    st.write(f"**Found in:** *\"{item['original_snippet']}\"*")
                    st.write(f"**Why change:** {item['reason']}")
                    alt_html = " ".join([f"<span class='pill-green'>👉 {alt}</span>" for alt in item["suggestions"]])
                    st.markdown(f"**Recommended Power Replacements:**<br>{alt_html}", unsafe_allow_html=True)
        else:
            st.success("🎉 Excellent! No weak or passive responsibility phrases found in your resume.")

        # Buzzwords & Clichés
        st.markdown("---")
        st.markdown(f"### 🚩 Overused Buzzwords & Clichés ({len(style_data['buzzwords'])})")
        if style_data["buzzwords"]:
            for bw in style_data["buzzwords"]:
                st.warning(f"**Term:** `{bw['term']}` (Line {bw['line_number']})\n\n**Advice:** {bw['explanation']}")
        else:
            st.success("✅ Clean! No cliché corporate buzzwords (e.g. 'rockstar', 'think outside the box') detected.")

        # First-Person Pronouns Check
        st.markdown("---")
        st.markdown(f"### 👤 First-Person Pronoun Check ({len(style_data['first_person_usage'])})")
        if style_data["first_person_usage"]:
            st.error(f"Found {len(style_data['first_person_usage'])} instances of first-person pronouns ('I', 'me', 'my', 'we'). Resumes should use implied first person.")
            for fp in style_data["first_person_usage"][:5]:
                st.write(f"• Line {fp['line_number']}: *\"{fp['snippet']}\"*")
        else:
            st.success("✅ Implied first-person voice used correctly throughout.")

        # Power Verbs Reference Table
        st.markdown("---")
        st.subheader("📚 Executive Power Verbs Cheat Sheet")
        for domain, verbs in POWER_VERBS_BY_DOMAIN.items():
            st.write(f"**{domain}:**")
            pills = " ".join([f"<span class='skill-pill'>{v}</span>" for v in verbs])
            st.markdown(pills, unsafe_allow_html=True)

    # ---------------- TAB 4: JOB DESCRIPTION MATCHER ----------------
    with tab_jd:
        st.subheader("🔍 Target Job Description Matcher (ATS Tailoring)")
        st.caption("Paste a job posting below or in the sidebar to simulate ATS keyword filtering for that position.")
        
        target_jd = st.text_area(
            "Target Job Description:",
            value=jd_input,
            height=180,
            placeholder="Paste target job requirements / responsibilities here..."
        )
        
        if st.button("🚀 Calculate ATS Match Against Job Description", type="primary") or jd_match:
            active_jd = target_jd if target_jd.strip() else jd_input
            if not active_jd.strip():
                st.warning("Please paste a target Job Description to compare against.")
            else:
                computed_match = match_job_description(resume_text, active_jd, skills_data["all_skills"])
                match_pct = computed_match.get("match_percentage", 0)
                
                col_j1, col_j2 = st.columns([1, 2])
                with col_j1:
                    st.markdown(f"""
                    <div class="metric-card" style="text-align: center;">
                        <div style="font-size: 1.1rem; color: #6B7280; font-weight: 700;">JOB MATCH RATE</div>
                        <div class="score-badge" style="color: {'#10B981' if match_pct >= 70 else '#F59E0B' if match_pct >= 50 else '#EF4444'};">
                            {match_pct}%
                        </div>
                        <p>Total Keywords Evaluated: {computed_match.get('total_jd_keywords', 0)}</p>
                    </div>
                    """, unsafe_allow_html=True)
                    
                with col_j2:
                    st.progress(int(match_pct))
                    if match_pct >= 75:
                        st.success("🎉 **High Match!** Your resume contains most keywords required for this job description.")
                    elif match_pct >= 50:
                        st.info("⚠️ **Moderate Match.** Adding the missing keywords below will significantly increase interview callbacks.")
                    else:
                        st.warning("⚠️ **Low Match.** Your resume is missing several core keywords specified in this job posting.")

                col_jm, col_jmiss = st.columns(2)
                with col_jm:
                    st.markdown("### ✅ Matched Keywords Found in Resume")
                    if computed_match.get("matched_skills"):
                        pills = " ".join([f"<span class='pill-green'>✓ {s}</span>" for s in computed_match["matched_skills"]])
                        st.markdown(pills, unsafe_allow_html=True)
                    else:
                        st.write("No matching keywords found.")
                        
                with col_jmiss:
                    st.markdown("### ❌ Missing Critical Keywords to Add")
                    if computed_match.get("missing_skills"):
                        pills = " ".join([f"<span class='missing-pill'>+ {s}</span>" for s in computed_match["missing_skills"]])
                        st.markdown(pills, unsafe_allow_html=True)
                        st.caption("Tip: Add these missing keywords naturally into your Work Experience bullet points or Skills section.")
                    else:
                        st.success("All identified keywords from the Job Description are already in your resume!")

    # ---------------- TAB 5: EXPORT REPORT ----------------
    with tab_export:
        st.subheader("📥 Export Complete Resume Audit Report")
        st.caption("Download your comprehensive ATS audit and career recommendation breakdown.")
        
        report_content = f"""# ATS RESUME AUDIT & CAREER OPTIMIZATION REPORT
Generated by AI & ATS Resume Analyzer

=======================================================
1. EXECUTIVE SUMMARY
=======================================================
Candidate Name: {contact_info['name']}
Overall ATS Score: {ats_result['overall_score']} / 100 (Grade: {ats_result['grade']})
ATS Status: {ats_result['status']}
Assessed Experience Tier: {experience_tier['badge']}
Total Word Count: {ats_result['word_count']} words

=======================================================
2. ATS SCORE BREAKDOWN
=======================================================
- Sections Completeness: {ats_result['breakdown']['Sections Completeness']['score']} / 20
- Contact Details: {ats_result['breakdown']['Contact Details']['score']} / 15
- Action Verbs & Metrics: {ats_result['breakdown']['Action Verbs & Metrics']['score']} / 25
- Skills Depth: {ats_result['breakdown']['Skills Density']['score']} / 20
- Formatting & Length: {ats_result['breakdown']['Formatting & Length']['score']} / 20

=======================================================
3. TOP RECOMMENDED JOB ROLES
=======================================================
"""
        for r in role_recommendations[:4]:
            report_content += f"\n- {r['role']} ({r['match_percentage']}% Match - {r['readiness']})\n"
            report_content += f"  Matched Skills: {', '.join(r['matched_skills']) if r['matched_skills'] else 'None'}\n"
            report_content += f"  Skill Gaps to Learn: {', '.join(r['missing_core_skills']) if r['missing_core_skills'] else 'None'}\n"
            report_content += f"  Roadmap: {r['roadmap']}\n"

        report_content += f"""
=======================================================
4. GRAMMAR & WORDING AUDIT
=======================================================
Style Score: {style_data['style_score']} / 100
Quantified Bullets Ratio: {style_data['metrics_stats']['metric_percentage']}%
Action Verb Ratio: {style_data['metrics_stats']['action_verb_percentage']}%
Weak/Passive Phrases Detected: {len(style_data['weak_words'])}
Buzzwords Detected: {len(style_data['buzzwords'])}
First-Person Pronouns Detected: {len(style_data['first_person_usage'])}

Actionable Fixes:
"""
        for imp in ats_result['improvements']:
            report_content += f"- {imp}\n"
            
        st.text_area("Report Preview:", value=report_content, height=350)
        
        st.download_button(
            label="⬇️ Download Full ATS Report (Markdown)",
            data=report_content,
            file_name=f"ATS_Resume_Report_{contact_info['name'].replace(' ', '_')}.md",
            mime="text/markdown"
        )


if __name__ == "__main__":
    main()
