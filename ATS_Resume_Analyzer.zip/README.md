# 📄 ATS Resume Analyzer & Career Optimizer

An intelligent, full-stack resume analysis application built in Python and Streamlit. It simulates modern Applicant Tracking Systems (ATS), performs deep semantic skill extraction, recommends best-fit job roles with career roadmaps, and provides line-by-line professional wording, grammar, and action-verb improvements.

---

## 🌟 Key Features

### 1. 📊 Comprehensive ATS Compatibility Score (0 - 100)
- **Section Completeness (20 pts):** Validates the presence of standard headers (Summary, Work Experience, Education, Skills, Projects, Certifications).
- **Contact Details (15 pts):** Checks for Email, Phone number, LinkedIn, GitHub, and Portfolio URLs.
- **Action Verbs & Impact Metrics (25 pts):** Evaluates quantifiable results (percentages, numbers, dollar metrics, scale) and executive power verbs.
- **Skills Depth & Repertoire (20 pts):** Catalogs technical competencies, tools, frameworks, and methodologies.
- **Formatting, Length & Readability (20 pts):** Analyzes word count (ideal 350–950 words for 1–2 pages) and bullet point quality.
- **ATS Letter Grades:** A+ (Strong Pass), B (Competitive), C (Needs Improvement), D (Screening Risk).

### 2. 🎯 Job Role Recommendations & Career Fit
- Analyzes candidate skills against 12+ industry standard domains:
  - **Full-Stack Developer**
  - **Backend Engineer**
  - **Frontend Engineer**
  - **Data Scientist**
  - **Machine Learning / AI Engineer**
  - **Data Analyst / BI Developer**
  - **DevOps & Cloud Engineer**
  - **Cybersecurity Analyst**
  - **Mobile App Developer**
  - **Product Manager**
  - **UI/UX Designer**
  - **QA & Test Automation Engineer**
- Computes **compatibility match percentage** for each role.
- Shows **Matched Skills You Have** vs. **Missing Core Skills (Skill Gaps)**.
- Provides a **tailored learning roadmap** to bridge skill gaps.
- Automatically infers **Assessed Career Level** (Entry, Mid, Senior, Lead).

### 3. ✍️ Professional Wording & Grammar Polish
- **Passive & Weak Verbs Detection:** Identifies phrases like *"responsible for"*, *"worked on"*, *"helped to"*, *"handled"*, *"duties included"* and suggests high-impact replacements (e.g. *Spearheaded, Architected, Orchestrated*).
- **Corporate Buzzwords & Clichés Filter:** Flags overused buzzwords (*"team player"*, *"think outside the box"*, *"rockstar"*, *"detail-oriented"*) and explains how to substantiate them with measurable proof.
- **First-Person Pronoun Check:** Detects non-standard pronouns (*I, my, me, we, our*) to maintain implied third/first person.
- **Interactive Bullet Point Polisher:** Lets you paste or type any sentence and instantly generates an executive, active-voice bullet point with metric prompts.
- **Grammar & Confused Words:** Catches tricky resume pitfalls like *lead vs. led*, *affect vs. effect*, *loose vs. lose*.
- **Executive Power Verbs Cheat Sheet:** Grouped by Leadership, Technical, Data, Innovation, and Business Impact.

### 4. 🔍 Target Job Description Matcher (ATS Tailoring)
- Paste any specific job posting from LinkedIn, Indeed, or company career portals.
- Calculates your **exact match percentage** against that specific job.
- Discovers **Critical Missing Keywords** that ATS filters will look for so you can naturally weave them into your resume before applying.

### 5. 📥 Exportable ATS Audit Report
- Generates a downloadable Markdown/Text report detailing your full evaluation, breakdown, and action items.

---

## 🚀 How to Run

1. Open PowerShell or Terminal in the project folder:
   ```bash
   cd c:\Users\DELL\OneDrive\Desktop\resume
   ```

2. Start the application:
   ```bash
   py -m streamlit run app.py
   ```
   *Or simply double-click `run_app.bat`!*

3. Open your browser at:
   ```
   http://localhost:8501
   ```

---

## 📁 File Structure
- [`app.py`](file:///c:/Users/DELL/OneDrive/Desktop/resume/app.py): Main Streamlit web application and UI dashboards.
- [`analyzer_engine.py`](file:///c:/Users/DELL/OneDrive/Desktop/resume/analyzer_engine.py): PDF/DOCX parsers, contact extractor, skills classifier, ATS scoring formula, and JD matcher.
- [`role_recommender.py`](file:///c:/Users/DELL/OneDrive/Desktop/resume/role_recommender.py): Role taxonomy database, skill gap analyzer, and career roadmaps.
- [`grammar_style_checker.py`](file:///c:/Users/DELL/OneDrive/Desktop/resume/grammar_style_checker.py): Weak words detector, buzzword cleaner, bullet polisher, and grammar rules.
- [`run_app.bat`](file:///c:/Users/DELL/OneDrive/Desktop/resume/run_app.bat): 1-click Windows launcher.
- [`requirements.txt`](file:///c:/Users/DELL/OneDrive/Desktop/resume/requirements.txt): Python dependencies.
