"""
Grammar, Style & Professional Wording Checker Module
Analyzes resumes for weak phrasing, passive voice, clichés, grammatical confusions,
and provides professional action-oriented recommendations.
"""

import re
from typing import List, Dict, Any, Tuple

# Comprehensive dictionary of weak / passive phrases and their strong replacements
WEAK_WORDS_MAP = {
    r"\b(responsible for|was responsible for)\b": {
        "phrase": "responsible for",
        "category": "Passive Responsibility",
        "alternatives": ["Spearheaded", "Directed", "Orchestrated", "Managed", "Led"],
        "reason": "'Responsible for' sounds like a passive job duty list rather than an achievement."
    },
    r"\b(helped\s+(to|with)?|assisted\s+(with|in)?)\b": {
        "phrase": "helped / assisted",
        "category": "Understated Impact",
        "alternatives": ["Collaborated with", "Facilitated", "Accelerated", "Supported", "Co-engineered"],
        "reason": "'Helped/Assisted' diminishes your personal contribution and ownership."
    },
    r"\b(worked on)\b": {
        "phrase": "worked on",
        "category": "Vague Action",
        "alternatives": ["Architected", "Engineered", "Implemented", "Designed", "Executed"],
        "reason": "'Worked on' is too vague; state specifically what you built, fixed, or delivered."
    },
    r"\b(handled)\b": {
        "phrase": "handled",
        "category": "Low-Impact Verb",
        "alternatives": ["Administered", "Orchestrated", "Resolved", "Coordinated", "Negotiated"],
        "reason": "'Handled' sounds like routine clerical maintenance rather than proactive leadership."
    },
    r"\b(duties included|tasks included)\b": {
        "phrase": "duties included",
        "category": "Job Description Copying",
        "alternatives": ["Delivered", "Pioneered", "Championed", "Executed key initiatives in"],
        "reason": "Recruiters want your actual results, not a copy-paste of job description duties."
    },
    r"\b(did|does|doing)\b": {
        "phrase": "did / doing",
        "category": "Weak Verb",
        "alternatives": ["Executed", "Performed", "Constructed", "Deployed", "Fulfilled"],
        "reason": "'Did' is generic and carries zero technical or business weight."
    },
    r"\b(tried to|attempted to)\b": {
        "phrase": "tried / attempted to",
        "category": "Uncertain Execution",
        "alternatives": ["Piloted", "Spearheaded", "Initiated", "Conducted proof-of-concept for"],
        "reason": "'Tried' signals incomplete work or lack of confidence."
    },
    r"\b(made)\b": {
        "phrase": "made",
        "category": "Basic Verb",
        "alternatives": ["Produced", "Authored", "Generated", "Fabricated", "Formulated"],
        "reason": "'Made' is basic. Use precise verbs like 'Authored' or 'Engineered'."
    },
    r"\b(fixed)\b": {
        "phrase": "fixed",
        "category": "Informal Verb",
        "alternatives": ["Resolved", "Debugged", "Remediated", "Optimized", "Restored"],
        "reason": "'Fixed' is conversational. 'Resolved', 'Remediated', or 'Debugged' sound professional."
    },
    r"\b(look after|looked after)\b": {
        "phrase": "looked after",
        "category": "Informal Phrasing",
        "alternatives": ["Supervised", "Oversaw", "Maintained", "Governed", "Protected"],
        "reason": "'Looked after' is casual. Use 'Oversaw' or 'Governed'."
    },
    r"\b(talked to|talked with)\b": {
        "phrase": "talked to/with",
        "category": "Informal Communication",
        "alternatives": ["Liaised with", "Negotiated with", "Consulted with", "Briefed", "Advised"],
        "reason": "'Talked to' doesn't convey business presence. Use 'Liaised with' or 'Advised'."
    },
    r"\b(changed)\b": {
        "phrase": "changed",
        "category": "Vague Change",
        "alternatives": ["Transformed", "Overhauled", "Revitalized", "Modernized", "Restructured"],
        "reason": "'Changed' is bland. State whether you 'Modernized', 'Overhauled', or 'Automated'."
    },
    r"\b(learned)\b": {
        "phrase": "learned",
        "category": "Student Phrasing",
        "alternatives": ["Mastered", "Acquired expertise in", "Adopted", "Specialized in"],
        "reason": "In professional resumes, emphasize capability ('Mastered') over student mindset ('Learned')."
    },
    r"\b(participated in)\b": {
        "phrase": "participated in",
        "category": "Passive Involvement",
        "alternatives": ["Contributed to", "Co-authored", "Co-led", "Drove components of"],
        "reason": "'Participated in' hides your specific contribution."
    }
}

# Buzzwords and Clichés that recruiters and ATS filter or dislike
BUZZWORDS = {
    "team player": "Overused cliché. Instead, show how you collaborated: 'Partnered with cross-functional teams to deliver...'",
    "hard worker": "Unsubstantiated claim. Demonstrate diligence with quantified output or delivery speed.",
    "hardworking": "Cliché. Showcase tangible accomplishments instead of self-descriptors.",
    "think outside the box": "Major corporate cliché. Replace with 'Developed innovative solutions' or 'Pioneered new approach'.",
    "go-getter": "Informal and unsubstantiated. Replace with 'Proactive initiator' or 'Self-directed'.",
    "detail-oriented": "Cliché. Prove it by showcasing high accuracy, zero-downtime releases, or quality audits.",
    "results-driven": "Buzzword. Prove results directly: 'Delivered 25% cost reduction' speaks louder.",
    "fast learner": "Sounds like junior filler. Replace with 'Rapidly adopted [Tech Stack] within 2 weeks'.",
    "self-starter": "Vague buzzword. Demonstrate self-initiated projects or independent ownership.",
    "strategic thinker": "Vague buzzword unless paired with specific enterprise strategies or roadmaps.",
    "synergy": "Outdated corporate jargon. Use 'Cross-functional alignment' or 'Integrated workflow'.",
    "rockstar": "Informal and non-ATS friendly. Replace with 'Top-tier specialist' or 'Lead engineer'.",
    "ninja": "Informal and unprofessional. Use precise professional title.",
    "guru": "Unprofessional filler. Use 'Subject Matter Expert (SME)' or 'Specialist'.",
    "passionate about": "Vague sentiment. Let your certifications, side projects, and accomplishments show your passion.",
    "perfectionist": "Can be interpreted as someone who struggles with deadlines or delegation.",
    "punctual": "Expected baseline minimum, not an accomplishment. Remove.",
    "dynamic": "Overused filler adjective with no measurable substance.",
    "seasoned": "Can trigger subtle age bias or feel like a cliché. Specify exact years of experience or depth.",
    "hit the ground running": "Cliché idiom. Replace with 'Quickly achieved productive velocity in [domain]'."
}

# Commonly confused grammatical words / typos in resumes
GRAMMAR_CONFUSIONS = [
    {
        "pattern": r"\b(lead)\b(?=\s+(a\s+team|the\s+project|the\s+development|the\s+effort|initiatives|cross-functional))",
        "issue": "Tense confusion: 'Lead' vs 'Led'",
        "correction": "Use 'Led' (past tense) if referring to completed or past work experience.",
        "severity": "High"
    },
    {
        "pattern": r"\b(their)\b(?=\s+(is|are|was|were|has|have)\b)",
        "issue": "Confused Word: 'Their' vs 'There'",
        "correction": "Did you mean 'There'?",
        "severity": "Medium"
    },
    {
        "pattern": r"\b(there)\b(?=\s+(responsibilities|skills|code|system|work)\b)",
        "issue": "Confused Word: 'There' vs 'Their'",
        "correction": "Did you mean 'Their' (possessive)?",
        "severity": "Medium"
    },
    {
        "pattern": r"\b(affect)\b(?=\s+(on|upon)\b)",
        "issue": "Confused Word: 'Affect' vs 'Effect'",
        "correction": "'Affect' is typically a verb, while 'Effect' is a noun ('had an effect on').",
        "severity": "Medium"
    },
    {
        "pattern": r"\b(loose)\b(?=\s+(data|clients|customers|revenue|time)\b)",
        "issue": "Typo: 'Loose' vs 'Lose'",
        "correction": "Use 'Lose' (to suffer loss), not 'Loose' (not tight).",
        "severity": "High"
    },
    {
        "pattern": r"\b(principal)\b(?=\s+(reasons|concept|values|rule)\b)",
        "issue": "Confused Word: 'Principal' vs 'Principle'",
        "correction": "'Principle' means fundamental truth/rule; 'Principal' means chief/primary or school head.",
        "severity": "Low"
    },
    {
        "pattern": r"\b(complimented)\b(?=\s+(by|with)\b)",
        "issue": "Confused Word: 'Compliment' vs 'Complement'",
        "correction": "If things enhance each other, use 'Complemented'. 'Complimented' means praised.",
        "severity": "Low"
    },
    {
        "pattern": r"\b(everyday)\b(?=\s+(I|we|tasks\s+were\s+done)\b)",
        "issue": "'Everyday' vs 'Every day'",
        "correction": "'Everyday' is an adjective ('everyday tasks'). Use 'Every day' as an adverbial time expression.",
        "severity": "Low"
    }
]

# Power Action Verbs by Functional Area for recommendations
POWER_VERBS_BY_DOMAIN = {
    "Leadership & Management": [
        "Spearheaded", "Orchestrated", "Pioneered", "Steered", "Mobilized",
        "Empowered", "Cultivated", "Decentralized", "Oversaw", "Mentored"
    ],
    "Engineering & Technical": [
        "Architected", "Engineered", "Implemented", "Refactored", "Containerized",
        "Automated", "Deployed", "Configured", "Benchmarked", "Optimized"
    ],
    "Data & Analytics": [
        "Modeled", "Forecasted", "Extracted", "Synthesized", "Quantified",
        "Uncovered", "Visualized", "Correlated", "Audited", "Streamlined"
    ],
    "Innovation & Problem Solving": [
        "Overhauled", "Revamped", "Troubleshot", "Debugged", "Resolved",
        "Mitigated", "Redesigned", "Streamlined", "Standardized", "Transformed"
    ],
    "Business & Impact": [
        "Accelerated", "Maximized", "Generated", "Boosted", "Negotiated",
        "Captured", "Retained", "Expanded", "Reduced", "Consolidated"
    ]
}


def analyze_grammar_and_wording(text: str) -> Dict[str, Any]:
    """
    Performs a deep audit of wording quality, weak phrases, buzzwords,
    grammatical pitfalls, and bullet point impact.
    """
    lines = [line.strip() for line in text.split("\n") if line.strip()]
    
    weak_word_findings = []
    buzzword_findings = []
    grammar_findings = []
    first_person_findings = []
    bullet_quality_findings = []
    
    total_bullets = 0
    bullets_with_metrics = 0
    bullets_with_action_verbs = 0
    
    # 1. Weak Words & Passive Phrases check
    for line_idx, line in enumerate(lines):
        clean_line = line.lstrip("•-*– \t")
        if not clean_line:
            continue
            
        # Is this a bullet or list item?
        is_bullet = line.startswith(("-", "•", "*", "–")) or re.match(r"^\d+[\.\)]", line)
        if is_bullet:
            total_bullets += 1
            # Check for metric / quantifier
            if re.search(r"(\d+%|\$\d+|\d+\+|\b\d+\b\s*(users|clients|projects|features|x|times|hours|ms|seconds|dollars|percent))", line, re.I):
                bullets_with_metrics += 1
            
            # Check if starts with strong action verb
            first_word_match = re.match(r"^([A-Z][a-z]+ed|[A-Z][a-z]+ing|[A-Z][a-z]+s|[A-Z][a-z]+)\b", clean_line)
            if first_word_match:
                first_word = first_word_match.group(1).lower()
                # Check against known power verbs
                all_power_verbs = {v.lower() for sub in POWER_VERBS_BY_DOMAIN.values() for v in sub}
                if first_word in all_power_verbs or first_word.endswith("ed"):
                    bullets_with_action_verbs += 1

        # Check weak phrases
        for pattern, info in WEAK_WORDS_MAP.items():
            matches = list(re.finditer(pattern, line, re.IGNORECASE))
            for m in matches:
                weak_word_findings.append({
                    "original_snippet": line[:100] + ("..." if len(line) > 100 else ""),
                    "detected_term": m.group(0),
                    "category": info["category"],
                    "suggestions": info["alternatives"],
                    "reason": info["reason"],
                    "line_number": line_idx + 1
                })

        # Check buzzwords
        for buzzword, explanation in BUZZWORDS.items():
            pattern = r"\b" + re.escape(buzzword) + r"\b"
            if re.search(pattern, line, re.IGNORECASE):
                buzzword_findings.append({
                    "term": buzzword,
                    "snippet": line[:100] + ("..." if len(line) > 100 else ""),
                    "explanation": explanation,
                    "line_number": line_idx + 1
                })

        # Check First-Person Pronouns (I, me, my, we, our)
        fp_match = re.search(r"\b(I|me|my|we|our|myself|ourselves)\b", line, re.IGNORECASE)
        if fp_match:
            first_person_findings.append({
                "pronoun": fp_match.group(0),
                "snippet": line[:100] + ("..." if len(line) > 100 else ""),
                "line_number": line_idx + 1,
                "tip": "Resumes should use implied first person. Instead of 'I developed a website', use 'Developed a website'."
            })

    # 2. Grammar Confusions check over full text
    for rule in GRAMMAR_CONFUSIONS:
        matches = list(re.finditer(rule["pattern"], text, re.IGNORECASE))
        for m in matches:
            # find line
            start = m.start()
            line_num = text[:start].count("\n") + 1
            snippet_start = max(0, start - 30)
            snippet_end = min(len(text), start + 50)
            grammar_findings.append({
                "issue": rule["issue"],
                "correction": rule["correction"],
                "severity": rule["severity"],
                "snippet": "..." + text[snippet_start:snippet_end].replace("\n", " ") + "...",
                "line_number": line_num
            })

    # 3. Bullet length and quality evaluation
    long_bullets = []
    short_bullets = []
    for line_idx, line in enumerate(lines):
        clean_line = line.lstrip("•-*– \t")
        words = clean_line.split()
        if line.startswith(("-", "•", "*", "–")) or (len(words) > 0 and clean_line[0].isupper()):
            if 3 < len(words) < 6:
                short_bullets.append({"line": line_idx + 1, "text": clean_line, "words": len(words)})
            elif len(words) > 42:
                long_bullets.append({"line": line_idx + 1, "text": clean_line[:90] + "...", "words": len(words)})

    # Calculate Grammar & Style Quality Score (out of 100)
    score = 100
    score -= min(30, len(weak_word_findings) * 5)
    score -= min(25, len(buzzword_findings) * 5)
    score -= min(20, len(first_person_findings) * 4)
    score -= min(15, len(grammar_findings) * 5)
    if total_bullets > 0 and bullets_with_metrics == 0:
        score -= 10
    
    score = max(20, score)

    return {
        "style_score": score,
        "weak_words": weak_word_findings,
        "buzzwords": buzzword_findings,
        "grammar_confusions": grammar_findings,
        "first_person_usage": first_person_findings,
        "metrics_stats": {
            "total_bullets": total_bullets,
            "bullets_with_metrics": bullets_with_metrics,
            "bullets_with_action_verbs": bullets_with_action_verbs,
            "metric_percentage": round((bullets_with_metrics / total_bullets * 100), 1) if total_bullets > 0 else 0,
            "action_verb_percentage": round((bullets_with_action_verbs / total_bullets * 100), 1) if total_bullets > 0 else 0
        },
        "bullet_length_issues": {
            "too_short": short_bullets,
            "too_long": long_bullets
        },
        "power_verbs_reference": POWER_VERBS_BY_DOMAIN
    }


def generate_sentence_improvement_preview(sentence: str) -> Dict[str, Any]:
    """
    Transforms a weak resume bullet point into a polished, professional one.
    """
    improved = sentence.strip()
    detected_weakness = []
    
    # Remove first-person
    fp_sub = re.sub(r"^(I|We)\s+(was\s+|were\s+)?", "", improved, flags=re.I)
    if fp_sub != improved:
        detected_weakness.append("Removed first-person pronoun")
        improved = fp_sub

    # Replace weak phrases
    for pattern, info in WEAK_WORDS_MAP.items():
        if re.search(pattern, improved, re.I):
            best_replacement = info["alternatives"][0]
            improved = re.sub(pattern, best_replacement, improved, flags=re.I)
            detected_weakness.append(f"Replaced '{info['phrase']}' with '{best_replacement}'")

    # Add metric placeholder suggestion if missing
    has_metric = bool(re.search(r"(\d+%|\$\d+|\d+\+)", improved))
    if not has_metric:
        recommendation = "Add quantified outcome (e.g. 'resulting in a 20% increase in performance' or 'saving 15 hours weekly')."
    else:
        recommendation = "Great job including quantifiable metrics!"

    return {
        "original": sentence,
        "polished": improved[0].upper() + improved[1:] if improved else sentence,
        "changes": detected_weakness,
        "quantifier_tip": recommendation
    }
