"""
Job Role Recommender Module
Analyzes candidate skills, experience, and tools to match against industry roles,
compute compatibility scores, and generate customized skill gap roadmaps.
"""

import re
from typing import List, Dict, Any, Set

ROLE_TAXONOMY = {
    "Full-Stack Developer": {
        "domain": "Software Engineering",
        "core_skills": ["javascript", "typescript", "react", "node.js", "nodejs", "express", "html", "css", "sql", "git", "rest api"],
        "bonus_skills": ["docker", "next.js", "mongodb", "postgresql", "graphql", "tailwind", "aws", "redux", "ci/cd", "redis"],
        "description": "Designs, develops, and deploys both client-facing interfaces and scalable backend server architectures.",
        "growth_recommendation": "Strengthen cloud deployment (AWS/GCP), microservices architecture, and system design patterns."
    },
    "Backend Engineer": {
        "domain": "Software Engineering",
        "core_skills": ["python", "java", "golang", "c#", "node.js", "django", "fastapi", "spring boot", "sql", "postgresql", "rest api", "microservices"],
        "bonus_skills": ["docker", "kubernetes", "redis", "kafka", "rabbitmq", "aws", "gcp", "grpc", "ci/cd", "nosql", "elasticsearch"],
        "description": "Architects resilient databases, server APIs, and backend distributed systems.",
        "growth_recommendation": "Deepen distributed systems knowledge, event-driven streaming (Kafka), and caching strategies."
    },
    "Frontend Engineer": {
        "domain": "Software Engineering",
        "core_skills": ["javascript", "typescript", "react", "vue", "angular", "html5", "css3", "tailwind css", "redux", "responsive design", "git"],
        "bonus_skills": ["next.js", "webpack", "vite", "jest", "cypress", "ui/ux", "web vitals", "sass", "graphql"],
        "description": "Builds high-performance, accessible, and delightful interactive web user interfaces.",
        "growth_recommendation": "Focus on Web Vitals optimization, state management architectures, and automated end-to-end testing."
    },
    "Data Scientist": {
        "domain": "Data Science & AI",
        "core_skills": ["python", "r", "pandas", "numpy", "scikit-learn", "sql", "machine learning", "statistics", "data analysis", "data visualization"],
        "bonus_skills": ["deep learning", "tensorflow", "pytorch", "nlp", "transformers", "tableau", "bigquery", "feature engineering", "mlflow"],
        "description": "Extracts actionable insights and predictive models from complex structured and unstructured datasets.",
        "growth_recommendation": "Build end-to-end ML pipelines with MLOps frameworks and experiment with modern LLM fine-tuning."
    },
    "Machine Learning / AI Engineer": {
        "domain": "Data Science & AI",
        "core_skills": ["python", "pytorch", "tensorflow", "machine learning", "deep learning", "nlp", "llms", "model training", "scikit-learn"],
        "bonus_skills": ["hugging face", "transformers", "langchain", "mlops", "docker", "kubeflow", "computer vision", "cuda", "onnx", "fastapi"],
        "description": "Develops, trains, optimizes, and serves artificial intelligence and deep neural network models in production.",
        "growth_recommendation": "Master agentic workflows (LangGraph/LlamaIndex), vector databases, and high-throughput inference serving."
    },
    "Data Analyst / BI Developer": {
        "domain": "Data Science & AI",
        "core_skills": ["sql", "excel", "tableau", "power bi", "python", "data visualization", "reporting", "dashboards", "business intelligence"],
        "bonus_skills": ["pandas", "etl", "snowflake", "bigquery", "dbt", "kpi tracking", "statistics", "alteryx"],
        "description": "Translates raw business numbers into executive visual dashboards, trends, and analytical reports.",
        "growth_recommendation": "Expand into automated ETL pipelines using dbt/Airflow and advanced predictive analytics."
    },
    "DevOps & Cloud Engineer": {
        "domain": "Cloud & Infrastructure",
        "core_skills": ["aws", "azure", "gcp", "docker", "kubernetes", "terraform", "ci/cd", "linux", "bash", "git"],
        "bonus_skills": ["ansible", "jenkins", "github actions", "prometheus", "grafana", "helm", "networking", "python", "iam", "cloudformation"],
        "description": "Automates cloud deployment pipelines, container orchestration, infrastructure-as-code, and system reliability.",
        "growth_recommendation": "Gain multi-cloud certifications and master GitOps and site reliability engineering (SRE) practices."
    },
    "Cybersecurity Analyst": {
        "domain": "Security & Networking",
        "core_skills": ["network security", "siem", "penetration testing", "vulnerability assessment", "incident response", "firewalls", "linux", "security"],
        "bonus_skills": ["wireshark", "splunk", "soc", "owasp", "cryptography", "python", "iso 27001", "cissp", "ceh", "threat hunting"],
        "description": "Protects organizational infrastructure, monitors suspicious network activity, and remediates security vulnerabilities.",
        "growth_recommendation": "Pursue hands-on capture-the-flag (CTF) challenges, cloud security posture management, and incident automation."
    },
    "Mobile Application Developer": {
        "domain": "Mobile Development",
        "core_skills": ["flutter", "react native", "swift", "kotlin", "dart", "ios", "android", "mobile development", "git"],
        "bonus_skills": ["xcode", "android studio", "firebase", "sqlite", "app store", "play store", "graphql", "offline storage", "biometrics"],
        "description": "Engineers native and cross-platform mobile experiences for iOS and Android devices.",
        "growth_recommendation": "Focus on offline-first database synchronization, performance profiling, and declarative UI animations."
    },
    "Product Manager": {
        "domain": "Product & Strategy",
        "core_skills": ["product strategy", "roadmap", "user stories", "agile", "scrum", "jira", "stakeholder management", "market research"],
        "bonus_skills": ["a/b testing", "prd", "feature prioritization", "kpis", "ux design", "sql", "data analytics", "customer discovery"],
        "description": "Defines product vision, aligns cross-functional engineering and design squads, and maximizes customer business value.",
        "growth_recommendation": "Sharpen data-driven experimentation (A/B testing) and deep customer interviewing techniques."
    },
    "UI/UX Designer": {
        "domain": "Design & User Experience",
        "core_skills": ["figma", "wireframing", "prototyping", "user research", "usability testing", "ui design", "ux design", "design systems"],
        "bonus_skills": ["adobe xd", "adobe illustrator", "information architecture", "interaction design", "accessibility", "html/css", "micro-interactions"],
        "description": "Creates intuitive user flows, comprehensive design systems, high-fidelity prototypes, and user experiences.",
        "growth_recommendation": "Deepen knowledge of WCAG 2.2 accessibility standards and token-based design systems."
    },
    "QA & Test Automation Engineer": {
        "domain": "Software Quality",
        "core_skills": ["selenium", "cypress", "playwright", "test automation", "qa", "manual testing", "jira", "test cases", "api testing", "postman"],
        "bonus_skills": ["pytest", "junit", "ci/cd", "performance testing", "jmeter", "cucumber", "bdd", "load testing"],
        "description": "Guarantees software reliability through automated test suites, regression pipelines, and performance stress testing.",
        "growth_recommendation": "Master modern headless frameworks (Playwright) and API contract testing in CI/CD pipelines."
    }
}


def normalize_skill(skill: str) -> str:
    """Normalize skill strings for matching."""
    s = skill.lower().strip()
    s = re.sub(r"[\.\s\-_/]+", " ", s)
    return s.strip()


def recommend_job_roles(extracted_skills: List[str], full_resume_text: str) -> List[Dict[str, Any]]:
    """
    Evaluates candidate's extracted skills and resume content against role profiles
    and returns a ranked list of job role matches.
    """
    lower_text = full_resume_text.lower()
    
    # Set of candidate skills normalized
    candidate_skills_set = {normalize_skill(s) for s in extracted_skills}
    
    recommendations = []
    
    for role_name, data in ROLE_TAXONOMY.items():
        core_skills = data["core_skills"]
        bonus_skills = data["bonus_skills"]
        
        matched_core = []
        missing_core = []
        matched_bonus = []
        missing_bonus = []
        
        # Check Core Skills
        for skill in core_skills:
            norm = normalize_skill(skill)
            # Match either via extracted skills or regex in full text
            pattern = r"\b" + re.escape(skill) + r"\b"
            if norm in candidate_skills_set or re.search(pattern, lower_text):
                matched_core.append(skill)
            else:
                missing_core.append(skill)
                
        # Check Bonus Skills
        for skill in bonus_skills:
            norm = normalize_skill(skill)
            pattern = r"\b" + re.escape(skill) + r"\b"
            if norm in candidate_skills_set or re.search(pattern, lower_text):
                matched_bonus.append(skill)
            else:
                missing_bonus.append(skill)
                
        total_core = len(core_skills)
        total_bonus = len(bonus_skills)
        
        # Core skills count for 75% of weight, bonus for 25%
        core_score = (len(matched_core) / total_core) * 75 if total_core > 0 else 0
        bonus_score = (len(matched_bonus) / total_bonus) * 25 if total_bonus > 0 else 0
        
        match_percentage = round(core_score + bonus_score, 1)
        
        # Categorize readiness
        if match_percentage >= 75:
            readiness = "High Fit (Ready to Apply)"
            badge_color = "green"
        elif match_percentage >= 50:
            readiness = "Moderate Fit (Minor Skill Gaps)"
            badge_color = "orange"
        else:
            readiness = "Potential Career Pivot"
            badge_color = "blue"
            
        recommendations.append({
            "role": role_name,
            "domain": data["domain"],
            "match_percentage": match_percentage,
            "readiness": readiness,
            "badge_color": badge_color,
            "matched_skills": sorted(list(set(matched_core + matched_bonus))),
            "missing_core_skills": missing_core,
            "missing_bonus_skills": missing_bonus[:4],
            "description": data["description"],
            "roadmap": data["growth_recommendation"]
        })
        
    # Sort roles by match percentage descending
    recommendations.sort(key=lambda x: x["match_percentage"], reverse=True)
    return recommendations


def determine_experience_level(text: str) -> Dict[str, Any]:
    """
    Infers candidate experience tier (Entry, Mid, Senior, Lead/Executive).
    """
    lower = text.lower()
    
    # Look for explicit years of experience
    year_matches = re.findall(r"(\d+)\+?\s*(?:years?|yrs?)(?:\s+of)?\s+(?:experience|exp)", lower)
    years = [int(y) for y in year_matches if y.isdigit() and int(y) < 50]
    max_years = max(years) if years else 0
    
    # Senior / Lead indicator keywords
    lead_keywords = ["architect", "director", "principal", "staff engineer", "vp", "head of", "lead", "managed a team"]
    senior_keywords = ["senior", "sr.", "spearheaded", "mentored", "orchestrated", "lead developer"]
    
    lead_count = sum(1 for kw in lead_keywords if re.search(r"\b" + re.escape(kw) + r"\b", lower))
    senior_count = sum(1 for kw in senior_keywords if re.search(r"\b" + re.escape(kw) + r"\b", lower))
    
    if max_years >= 8 or lead_count >= 2:
        level = "Lead / Principal / Executive"
        badge = "Senior Tier (8+ Years / Leadership)"
    elif max_years >= 4 or senior_count >= 2:
        level = "Senior Professional"
        badge = "Mid-to-Senior Tier (4-7 Years)"
    elif max_years >= 2:
        level = "Mid-Level Professional"
        badge = "Mid Tier (2-4 Years)"
    else:
        level = "Entry-Level / Early Career"
        badge = "Entry Tier (0-2 Years)"
        
    return {
        "level": level,
        "badge": badge,
        "detected_years": max_years if max_years > 0 else "Not explicitly stated"
    }
